// A $( document ).ready() block.
$(document).ready(function () {}); //end of document ready
AOS.init();
